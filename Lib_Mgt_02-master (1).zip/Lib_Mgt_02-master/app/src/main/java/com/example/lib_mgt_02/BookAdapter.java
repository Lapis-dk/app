package com.example.lib_mgt_02;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class BookAdapter extends ArrayAdapter<Book> {
    FirebaseHelper database;
    String userId;
    public BookAdapter(@NonNull Context context, List<Book> bookList, String id) {
        super(context, 0, bookList);
        userId = id;
        database = new FirebaseHelper();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.card_book, parent, false);
        }
        Book book = getItem(position);
        int booksLeft = book.getCount() - book.getLent().size();
        TextView title = view.findViewById(R.id.titleTextView);
        TextView author = view.findViewById(R.id.authorTextView);
        TextView availability = view.findViewById(R.id.availabilityTextView);
        Button getOrReserve = view.findViewById(R.id.getOrReserveButton);
        title.setText(book.getTitle());
        author.setText(book.getAuthor());
        availability.setText("Books left : " + String.valueOf(booksLeft));
        getOrReserve.setText(booksLeft > 0 ? "Get" : "Reserve");
        if(book.getLent().contains(userId)) {
            getOrReserve.setText("Return");
        } else if(book.getReserved().contains(userId)) {
            getOrReserve.setText("Cancel Reserve");
        }
        getOrReserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                handleButtonClick(position, getOrReserve.getText().toString(), book.getId(), view);
            }
        });
        return view;
    }

    private void handleButtonClick(int position, String text, String bookId, View view) {
        switch (text) {
            case "Get":
                database.getBook(userId, bookId);
                break;
            case "Reserve":
                database.reserveBook(userId, bookId);
                break;
            case "Return":
                database.returnBook(userId, bookId);
                break;
            case "Cancel Reserve":
                database.cancelBookReserve(userId, bookId);
                break;
        }
        Intent intent = new Intent(view.getContext(), HomeActivity.class);
        Activity activity = (Activity) view.getContext();
        activity.startActivity(intent);
        activity.finish();
    }
}
