package com.example.lib_mgt_02;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class HomeActivity extends AppCompatActivity {

    FirebaseHelper database;
    User user;
    SharedPreferences preferences;

//    private UserViewModel userViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        preferences = getSharedPreferences("MyPreferences", Context.MODE_PRIVATE);
        database = new FirebaseHelper();
        database.getUserDetails(preferences.getString("email", ""), new FirebaseHelper.OngetUserDetailsCallback() {
            @Override
            public void ongetUserDetailsReceived(User USER) {
                user = USER;
                TextView usernameText = findViewById(R.id.usernameText);
                usernameText.setText(user.getName());

            }
        });

//        userViewModel = new ViewModelProvider(this).get(UserViewModel.class);
    }

    public void userLogout(View view) {

        SharedPreferences.Editor editor = preferences.edit();
        editor.remove("email");
        editor.remove("password");

        editor.apply();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();

    }

    public void myLentButtonClick(View view) {
        database.searchedUserBooks(user.getLent(), view, user.getId());
    }

    public void myReservedButtonClick(View view) {
        database.searchedUserBooks(user.getReserved(), view, user.getId());
    }

    public void searchBookButtonClick(View view) {
        EditText title = findViewById(R.id.searchBookTitle);
        EditText author = findViewById(R.id.searchBookAuthor);
        EditText genre = findViewById(R.id.searchBookGenre);
        database.searchedBooks(title.getText().toString().toLowerCase().trim(), author.getText().toString().toLowerCase().trim(), genre.getText().toString().toLowerCase().trim(), user.getId(), view);
    }
}