package com.example.lib_mgt_02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {

    FirebaseHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        database = new FirebaseHelper();
    }

    public void userLogin(View view) {
        TextView email = findViewById(R.id.emailText);
        TextView password = findViewById(R.id.passwordText);
        database.authenticateUser(email.getText().toString().trim(), password.getText().toString().trim(), view);
    }
}